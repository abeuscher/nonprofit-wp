<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'js' => ['bower_components/angular-ui-sortable/sortable.min.js'],
];
