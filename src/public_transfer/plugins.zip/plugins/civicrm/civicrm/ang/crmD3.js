(function (angular, $, _) {
  angular.module('crmD3', CRM.angRequires('crmD3'));
})(angular, CRM.$, CRM._);
