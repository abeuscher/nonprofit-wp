<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'js' => ['bower_components/angular-unsavedChanges/dist/unsavedChanges.min.js'],
];
