<?php
// @see crmDialog.md
return [
  'ext' => 'civicrm',
  'js' => [
    'ang/crmDialog.js',
  ],
  'requires' => [
    'dialogService',
  ],
  'basePages' => [],
];
