<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'js' => ['bower_components/angular-file-upload/dist/angular-file-upload.min.js'],
];
