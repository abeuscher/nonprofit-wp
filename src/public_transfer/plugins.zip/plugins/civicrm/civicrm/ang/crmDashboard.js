(function(angular, $, _) {
  angular.module('crmDashboard', CRM.angRequires('crmDashboard'));

  angular.module('crmDashboard', CRM.angular.modules);

})(angular, CRM.$, CRM._);
