(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('api4', CRM.angRequires('api4'));
})(angular, CRM.$, CRM._);
