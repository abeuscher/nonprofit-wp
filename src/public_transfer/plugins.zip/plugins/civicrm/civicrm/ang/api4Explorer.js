(function(angular, $, _) {
  // Declare a list of dependencies.
  angular.module('api4Explorer', CRM.angRequires('api4Explorer'));
})(angular, CRM.$, CRM._);
