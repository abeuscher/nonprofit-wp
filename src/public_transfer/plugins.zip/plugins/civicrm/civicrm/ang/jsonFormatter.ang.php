<?php

return [
  'ext' => 'civicrm',
  'js' => ['bower_components/json-formatter/dist/json-formatter.min.js'],
  'css' => ['bower_components/json-formatter/dist/json-formatter.min.css'],
  'requires' => [],
  'exports' => [
    'json-formatter' => 'E',
  ],
];
