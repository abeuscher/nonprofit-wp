<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'basePages' => [],
  'js' => ['bower_components/checklist-model/checklist-model.js'],
];
