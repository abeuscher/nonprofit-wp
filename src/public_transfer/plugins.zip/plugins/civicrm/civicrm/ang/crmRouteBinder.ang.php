<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'js' => ['ang/crmRouteBinder.js'],
  'css' => [],
  'partials' => [],
  'requires' => ['ngRoute'],
];
