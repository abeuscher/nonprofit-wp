<?php
// This module provides the D3 graphing library

return [
  'ext' => 'civicrm',
  'basePages' => [],
  'js' => [
    'ang/crmD3.js',
    'bower_components/d3-3.5.x/d3.min.js',
  ],
  'requires' => [],
];
