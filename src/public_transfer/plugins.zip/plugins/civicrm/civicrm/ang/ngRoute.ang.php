<?php
// This file declares an Angular module which can be autoloaded
return [
  'ext' => 'civicrm',
  'js' => ['bower_components/angular-route/angular-route.min.js'],
];
