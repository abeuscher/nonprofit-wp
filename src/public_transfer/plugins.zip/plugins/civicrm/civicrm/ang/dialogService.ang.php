<?php
// This file declares an Angular module which can be autoloaded
// https://github.com/jwstadler/angular-jquery-dialog-service

return [
  'ext' => 'civicrm',
  'js' => ['bower_components/angular-jquery-dialog-service/dialog-service.js'],
];
